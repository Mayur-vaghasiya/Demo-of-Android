package com.example.peacock.getcontactinfo;

import java.util.ArrayList;

/**
 * Created by peacock on 14/4/17.
 */

public class Contactlist {

    private String Name;
    private ArrayList<String> Contact;


    public Contactlist(String name, ArrayList<String> contact){
        this.Name=name;
        this.Contact=contact;

    }

    public String getName() {
        return this.Name;
    }

    public void setName(String name) {
       this.Name = name;
    }

    public ArrayList<String> getContact() {
        return this.Contact;
    }

    public void setContact(ArrayList contact) {
        this.Contact = contact;
    }
}
